console.log("Up and running!");
let cardOne = "queen";
let cardTwo = "queen";
let cardThree= "king";
let cardFour= "king";
console.log("User flipped " + cardOne);
console.log("User flipped " + cardThree);